

<?php $__env->startSection('content'); ?>

  <!-- Title -->
  <h1 class="mt-4"><?php echo e($post->title); ?></h1>

  <!-- Author -->
  <p class="lead">
    by
    <a href="#"><?php echo e($post->author); ?></a>
  </p>

  <hr>

  <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <span class="badge badge-pill badge-primary"><?php echo e($tag->name); ?></span>
    
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <hr>

  <!-- Date/Time -->
  <p>Posted on <?php echo e($post->created_at); ?></p>

  <hr>

  <!-- Preview Image -->
  <img class="img-fluid rounded" src="<?php echo e(asset( 'images/' . $post->image)); ?>" alt="">

  <hr>

  <!-- Post Content -->
  <p class="lead"><?php echo e($post->lead); ?></p>

  <p class="body"><?php echo e($post->body); ?></p>

  <hr>

  <div class="card my-4">
    <h5 class="card-header">Leave a Comment:</h5>
    <div class="card-body">
      <form method="POST" action="<?php echo e(url('/posts/'.$post->id.'/comments')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <textarea name="kommentar" class="form-control" rows="3"></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>

  <?php $__currentLoopData = $post->comments->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <!-- Single Comment -->
    <div class="media mb-4">
      <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
      <div class="media-body">
        <h5 class="mt-0"><?php echo e($comment->author); ?></h5>
        <?php echo e($comment->text); ?>

      </div>
    </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\simple-blog\resources\views/post.blade.php ENDPATH**/ ?>